/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework1;

import jade.core.Agent;
import jade.core.behaviours.*;
import java.util.*;

import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.FIPAException;
import java.util.*;
import jade.core.AID;
import jade.lang.acl.*;
import jade.proto.states.MsgReceiver;

/**
 *
 * @author dell
 */
public class TourGuideAgent extends Agent {
    private AID[] curatorAgents ;
    ACLMessage msg;
	
    protected void setup() 
    {
        ServiceDescription sd  = new ServiceDescription();
        sd.setType( "Virtual-Tour" ); //Representing service type
        sd.setName("Virtual-Tour"); 
        register( sd );
        
        addBehaviour(new TickerBehaviour(this, 10000) {
                protected void onTick()
                {
                    //update list of curators
                    DFAgentDescription template = new DFAgentDescription();
                    ServiceDescription sd = new ServiceDescription();
                    sd.setType("artifacts-list");
                    template.addServices(sd);
                    try {
                        DFAgentDescription[] result= DFService.search(myAgent,template);
                        curatorAgents = new AID[result.length];
                        for (int x = 0; x < result.length; x++) {
                            curatorAgents[x] = result[x].getName();
                            System.out.println("[TOUR GUIDE AGENT]Added curator: " +  result[x].getName());
                            ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
                            msg.addReceiver(curatorAgents[x]);
                            msg.setConversationId("11");
                            msg.setContent("ARTIFACT INFO");
                            send(msg);
                            msg.setConversationId("12");
                            msg.setContent("MUSEUM INFO");
                            send(msg);
                        }
                    } catch(FIPAException fe) { fe.printStackTrace();}
                }
            }
        );
        
        
        addBehaviour( new CyclicBehaviour(this)  //get messages from profiler
        {
            public void action() 
            {
                MessageTemplate mt = MessageTemplate.MatchPerformative(ACLMessage.QUERY_IF);
                ACLMessage msg = receive( mt );
                if (msg!=null) {
                    ACLMessage reply = msg.createReply();
                    reply.setPerformative( ACLMessage.CONFIRM );
                    reply.setContent("100");
                    addBehaviour( 
                      new WakerBehaviour( myAgent, 2000) //send reply after delay
                      {
                         public void handleElapsedTimeout() { 
                             send(reply); 
                         }
                      });
                }
                else
                    block();
            }
        });
       
        addBehaviour(new MsgRec());
    }
    
    protected class MsgRec extends MsgReceiver 
    {
        public void action() {
            MessageTemplate mt = MessageTemplate.MatchPerformative(ACLMessage.QUERY_REF);
            ACLMessage msg = myAgent.receive(mt);
            if (msg != null) {
                ACLMessage msgr = newMsg( ACLMessage.QUERY_REF ); 
                SequentialBehaviour seq = new SequentialBehaviour();
                addBehaviour( seq );

                ParallelBehaviour par = new ParallelBehaviour( ParallelBehaviour.WHEN_ALL );
                seq.addSubBehaviour( par );
                for (int i=0; i < curatorAgents.length; i++)
                {
                    msgr.addReceiver( curatorAgents[i]);
                    par.addSubBehaviour( new WakerBehaviour( myAgent, 1000) 
                       {
                          public void handleElapsedTimeout() 
                          {   
                                System.out.println("[TOUR GUIDE AGENT]Received response from curator");
                          }
                       });
                 }
                seq.addSubBehaviour( new OneShotBehaviour()
                {
                    public void action() 
                    {  
                       System.out.println("[TOUR GUIDE AGENT]Tour sent!");
                    }
                });
        
               //send ( msg );
                
            }
            else
                block();
        }
    }
    
    protected static int cidCnt = 0;
    String cidBase ;
   
    String genID() 
    { 
       if (cidBase==null) {
          cidBase = getLocalName() + hashCode() +
                       System.currentTimeMillis()%10000 + "_";
       }
       return  cidBase + (cidCnt++); 
    }
    ACLMessage newMsg( int perf, String content, AID dest)
    {
       ACLMessage msg = newMsg(perf);
       if (dest != null) 
           msg.addReceiver( dest );
       msg.setContent( content );
       return msg;
    }

    ACLMessage newMsg( int perf)
    {
       ACLMessage msg = new ACLMessage(perf);
       msg.setConversationId( genID() );
       return msg;
    }
    
    void register( ServiceDescription sd)
    {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        dfd.addServices(sd);
        try {  
            DFService.register(this, dfd );  
        } catch (FIPAException fe) { fe.printStackTrace(); }
    }
    
    protected void takeDown()
    {
        try {
            DFService.deregister(this);
        } catch(FIPAException fe) {
            fe.printStackTrace();
        }
        System.out.println("Agent: " +getAID().getName()+" terminating.");
    }
}
