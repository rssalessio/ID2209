/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework1;

/**
 *
 * @author dell
 */
public class Artifact {
    public int id;
    public String name;
    public String creator;
    public String creationDate;
    public String creationPlace;
    public String genre;
    public String genreDetails;
    public String description;
    
    public boolean Equals(Artifact me) {
        return this.id == me.id || this.name == me.name;
    }
}
