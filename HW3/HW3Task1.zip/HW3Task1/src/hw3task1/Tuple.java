/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw3task1;

import jade.core.AID;

/**
 *
 * @author dell
 */
public class Tuple{ 
  public AID agent;
  public int id;
  public Tuple(AID a, int i)
  {
      agent = a;
      id = i;
  }
} 
